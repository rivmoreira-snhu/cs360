package com.example.minimalcalendarapp_uionly;

public class DbConfig {
    public static final String DATABASE_NAME = "calendarApp.db";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "id";
    public static final String COLUMN_EVENT_TITLE = "title";
    public static final String COLUMN_EVENT_DATE = "date";

    // Update: Returns the database name via injected BuildConfig (secure &
    // portable)
    public static String getDatabaseName() {
        return BuildConfig.DB_NAME;
    }

    // Update: Version bump used to trigger schema migration from v1 to v2
    public static int getDatabaseVersion() {
        return BuildConfig.DB_VERSION;
    }

    // Update: API base URL, Sentry DSN, and Mongo URI pulled via environment
    // values (kept out of source control)
    public static String getApiBaseUrl() {
        return clean(BuildConfig.API_BASE_URL);
    }

    public static String getMongoUri() {
        return clean(BuildConfig.MONGO_URI);
    }

    public static String getSentryDsn() {
        return clean(BuildConfig.SENTRY_DSN);
    }

}
