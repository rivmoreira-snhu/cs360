package com.example.minimalcalendarapp_uionly;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


/**
 * This class handles SQLite database interactions for the app.
 * Enhancements include password hashing and improved security practices.
 */
public class DatabaseHelperEnhanced extends SQLiteOpenHelper {

    public DatabaseHelperEnhanced(Context context) {
        super(context, DbConfig.DATABASE_NAME, null, DbConfig.DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + DbConfig.TABLE_USERS + " ("
                + DbConfig.COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + DbConfig.COLUMN_USERNAME + " TEXT UNIQUE, "
                + DbConfig.COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        String createEventsTable = "CREATE TABLE " + DbConfig.TABLE_EVENTS + " ("
                + DbConfig.COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + DbConfig.COLUMN_EVENT_TITLE + " TEXT, "
                + DbConfig.COLUMN_EVENT_DATE + " TEXT)";
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DbConfig.TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + DbConfig.TABLE_EVENTS);
        onCreate(db);
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DbConfig.COLUMN_USERNAME, username);
        values.put(DbConfig.COLUMN_PASSWORD, SecurityUtils.hashPassword(password));

        long result = db.insert(DbConfig.TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String hashedPassword = SecurityUtils.hashPassword(password);
        String query = "SELECT * FROM " + DbConfig.TABLE_USERS +
                " WHERE " + DbConfig.COLUMN_USERNAME + "=? AND " + DbConfig.COLUMN_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, hashedPassword});

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close();
        return exists;
    }

    public boolean addEvent(String title, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DbConfig.COLUMN_EVENT_TITLE, title);
        values.put(DbConfig.COLUMN_EVENT_DATE, date);

        long result = db.insert(DbConfig.TABLE_EVENTS, null, values);
        db.close();

        return result != -1;
    }

    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + DbConfig.TABLE_EVENTS + " ORDER BY " + DbConfig.COLUMN_EVENT_DATE + " ASC";
        return db.rawQuery(query, null);
    }

    public boolean updateEvent(int id, String newTitle, String newDate) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DbConfig.COLUMN_EVENT_TITLE, newTitle);
        values.put(DbConfig.COLUMN_EVENT_DATE, newDate);

        int rows = db.update(DbConfig.TABLE_EVENTS, values, DbConfig.COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        db.close();

        return rows > 0;
    }

    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rows = db.delete(DbConfig.TABLE_EVENTS, DbConfig.COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(id)});
        db.close();

        return rows > 0;
    }

    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + DbConfig.TABLE_USERS +
                " WHERE " + DbConfig.COLUMN_USERNAME + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close();
        return exists;
    }
}