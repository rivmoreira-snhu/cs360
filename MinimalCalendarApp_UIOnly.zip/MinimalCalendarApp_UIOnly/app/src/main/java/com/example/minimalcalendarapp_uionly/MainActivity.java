package com.example.minimalcalendarapp_uionly;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;



public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        // Launch SMS permission screen
        Button smsPermissionButton = findViewById(R.id.requestSmsPermissionButton);
        smsPermissionButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SMSPermissionActivity.class);
            startActivity(intent);
        });

        // Launch calendar view
        Button calendarButton = findViewById(R.id.switchToCalendarButton);
        calendarButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, CalendarActivity.class);
            startActivity(intent);
        });

        // Launch Event view
        Button viewDatabaseButton = findViewById(R.id.viewDatabaseButton);
        viewDatabaseButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, DatabaseActivity.class);
            startActivity(intent);
        });

    }

}
