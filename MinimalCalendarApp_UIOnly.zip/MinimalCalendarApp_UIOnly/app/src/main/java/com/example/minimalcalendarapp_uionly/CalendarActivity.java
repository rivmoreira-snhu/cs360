package com.example.minimalcalendarapp_uionly;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CalendarActivity extends AppCompatActivity {

    private LinearLayout eventList;
    private Button addEventButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        eventList = findViewById(R.id.eventList);
        addEventButton = findViewById(R.id.addEventButton);
        TextView currentDateView = findViewById(R.id.currentDate);

        // Format the date to something friendly
        String currentDate = java.text.DateFormat.getDateInstance().format(new java.util.Date());
        currentDateView.setText(currentDate);

        // Initial dummy events
        addEvent("Drop off", "7:30 AM", "Vehicle");
        addEvent("Lunch with Sarah", "1:30 PM", "Compass Coffee");
        addEvent("Project Retrospective", "3:00 PM", "Zoom");

        // Add new dummy blank event
        addEventButton.setOnClickListener(view ->
                addEvent("New Event", "Time TBD", "Location TBD")
        );
    }

    // Inflate and insert event into list (adds to top)
    private void addEvent(String title, String time, String location) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View eventItem = inflater.inflate(R.layout.event_item, eventList, false);

        TextView titleView = eventItem.findViewById(R.id.eventTitle);
        TextView timeView = eventItem.findViewById(R.id.eventTime);
        TextView locationView = eventItem.findViewById(R.id.eventLocation);
        Button deleteButton = eventItem.findViewById(R.id.deleteButton);

        titleView.setText(title);
        timeView.setText(time);
        locationView.setText(location);
        // Remove on delete
        deleteButton.setOnClickListener(v -> eventList.removeView(eventItem));
        // add to bottom
        eventList.addView(eventItem);
    }
}
