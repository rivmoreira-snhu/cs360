// activity_login.xml.java
package com.example.minimalcalendarapp_uionly;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Log In Button
        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(view -> {
            // Simulate login -> Go to Main screen
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // optional, so activity_login.xml doesn't stay in backstack
        });

        // Optional: Sign Up Button (stubbed)
        Button signupButton = findViewById(R.id.signupButton);
        signupButton.setOnClickListener(view -> {
            // You can implement or stub this later
        });
    }
}

